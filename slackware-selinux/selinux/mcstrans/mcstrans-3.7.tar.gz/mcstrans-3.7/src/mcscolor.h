#ifndef __mcscolor_h__
#define __mcscolor_h__

extern void finish_context_colors(void);
extern int init_colors(void);
extern int raw_color(const char *raw, char **color_str);

#endif

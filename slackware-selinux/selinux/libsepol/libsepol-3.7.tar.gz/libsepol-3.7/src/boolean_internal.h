#ifndef _SEPOL_BOOLEAN_INTERNAL_H_
#define _SEPOL_BOOLEAN_INTERNAL_H_

#include <sepol/boolean_record.h>
#include <sepol/booleans.h>

#endif

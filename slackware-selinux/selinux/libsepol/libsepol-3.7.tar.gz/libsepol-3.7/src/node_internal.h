#ifndef _SEPOL_NODE_INTERNAL_H_
#define _SEPOL_NODE_INTERNAL_H_

#include <sepol/node_record.h>
#include <sepol/nodes.h>

#endif
